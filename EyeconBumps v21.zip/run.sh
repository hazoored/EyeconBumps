#!/bin/bash
# Use the working virtual environment in the home directory
/home/fearfaeri/.eyecon_venv/bin/python discord_bot.py
