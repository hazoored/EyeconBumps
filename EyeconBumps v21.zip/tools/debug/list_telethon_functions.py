from telethon.tl.functions import messages
import inspect

print(dir(messages))
