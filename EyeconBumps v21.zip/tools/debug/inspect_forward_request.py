from telethon.tl.functions.messages import ForwardMessagesRequest
import inspect

print(inspect.signature(ForwardMessagesRequest.__init__))
